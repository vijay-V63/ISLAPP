import cv2
import os
import time

# Define gesture labels and output directory
labels = ['Bye']  # Add more ISL gestures as needed
output_dir = 'isl_dataset'
os.makedirs(output_dir, exist_ok=True)
for label in labels:
    os.makedirs(os.path.join(output_dir, label), exist_ok=True)

# Initialize webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

print("Press 's' to start capturing, 'q' to quit, 'n' to switch gesture.")

current_label = 0
count = 0
capturing = False

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error: Failed to capture frame.")
        break

    # Display ROI (Region of Interest)
    roi = frame[50:300, 50:300]  # 250x250 pixel region
    cv2.rectangle(frame, (50, 50), (300, 300), (0, 255, 0), 2)
    cv2.putText(frame, f"Gesture: {labels[current_label]} ({count}/100)", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow("Capture", frame)
    key = cv2.waitKey(1) & 0xFF

    # Start capturing
    if key == ord('s'):
        capturing = True
        print(f"Capturing for {labels[current_label]}")
    # Save image
    elif capturing and count < 100:
        img_path = os.path.join(output_dir, labels[current_label], f"{count}_{int(time.time())}.jpg")
        cv2.imwrite(img_path, roi)
        count += 1
        print(f"Saved {img_path}")
        time.sleep(0.1)  # Small delay to avoid duplicate frames
    # Switch to next gesture
    elif key == ord('n'):
        if capturing:
            capturing = False
            count = 0
            current_label = (current_label + 1) % len(labels)
            print(f"Switched to {labels[current_label]}")
    # Quit
    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()